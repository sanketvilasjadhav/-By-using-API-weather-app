document.addEventListener('DOMContentLoaded', () => {
    const apiKey = '72aec7c5156b48c3b6c03122252107';
    const locationInput = document.getElementById('locationInput');
    const searchButton = document.getElementById('searchButton');
    const weatherCard = document.getElementById('weatherCard');
    const errorMessage = document.getElementById('errorMessage');

    // Function to fetch and display weather
    const getWeather = (location) => {
        const apiUrl = `https://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${location}&aqi=yes`;

        fetch(apiUrl)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if (data.error) {
                    showError(data.error.message);
                } else {
                    updateWeatherUI(data);
                    showWeatherCard();
                }
            })
            .catch(error => {
                console.error('Error fetching weather data:', error);
                showError('Could not find location. Please try again.');
            });
    };

    // Function to update the UI with weather data
    const updateWeatherUI = (data) => {
        document.getElementById('weatherIcon').src = `https:${data.current.condition.icon}`;
        document.getElementById('temperature').textContent = `${Math.round(data.current.temp_c)}°c`;
        document.getElementById('condition').textContent = data.current.condition.text;
        document.getElementById('locationName').textContent = `${data.location.name}, ${data.location.country}`;
    };

    // Function to show the weather card and hide errors
    const showWeatherCard = () => {
        errorMessage.style.display = 'none';
        weatherCard.style.display = 'block';
    };

    // Function to show an error message
    const showError = (message) => {
        weatherCard.style.display = 'none';
        errorMessage.textContent = message;
        errorMessage.style.display = 'block';
    };

    // Event listener for the search button
    searchButton.addEventListener('click', () => {
        const location = locationInput.value.trim();
        if (location) {
            getWeather(location);
        }
    });

    // Event listener for pressing Enter in the input field
    locationInput.addEventListener('keypress', (event) => {
        if (event.key === 'Enter') {
            const location = locationInput.value.trim();
            if (location) {
                getWeather(location);
            }
        }
    });

    // Initial weather display for London
    getWeather('London');
});